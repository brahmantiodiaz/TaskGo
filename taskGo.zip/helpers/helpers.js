function getValidationError(error) {
	const customError = {
		message: {},
	};

	error.errors.forEach((el) => {
		customError.message[el.path] = el.message;
	});

	return customError;
}
function getErrors(error) {
	const customError = {
		message: {},
	};

	if (error.errors) {
		error.errors.forEach((el) => {
			customError.message[el.path] = el.message;
		});
	} else {
		customError.message.general = error.message || "Something went wrong";
	}
}

function toIdr(num) {
	return new Intl.NumberFormat("id-ID", {
		style: "currency",
		currency: "IDR",
		minimumFractionDigits: 0,
	}).format(num);
}

module.exports = { getValidationError, toIdr };
